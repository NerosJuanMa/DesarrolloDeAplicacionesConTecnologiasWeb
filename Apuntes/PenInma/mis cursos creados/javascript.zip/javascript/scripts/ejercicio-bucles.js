// Ejercicio de Bucles: genera lista y estadísticas con for / for...of / while
(function () {
  const projects = [
    { titulo: "Landing IFCD0110", real: true },
    { titulo: "SPA HTML/CSS/JS", real: true },
    { titulo: "Portfolio Animaciones", real: false },
    { titulo: "Prácticas DOM y Eventos", real: false },
    { titulo: "Tienda Demo (Carrito)", real: false }
  ];

  const $ = (id) => document.getElementById(id);

  const rbFor    = $("loop-kind-for");
  const rbForOf  = $("loop-kind-forof");
  const rbWhile  = $("loop-kind-while");
  const btnGen   = $("btn-loop-generar");
  const btnClean = $("btn-loop-limpiar");
  const ul       = $("loop-list");
  const statsBox = $("loop-stats");

  if (!rbFor || !btnGen || !ul || !statsBox) return;

  function currentKind() {
    if (rbForOf.checked) return "forof";
    if (rbWhile.checked) return "while";
    return "for";
  }

  function pintarLista(kind) {
    ul.innerHTML = "";

    if (kind === "for") {
      for (let i = 0; i < projects.length; i++) {
        const p = projects[i];
        const li = document.createElement("li");
        li.textContent = `${i + 1}. ${p.titulo} ${p.real ? "🟢 Real" : "⚪ Demo"}`;
        ul.appendChild(li);
      }
    } else if (kind === "forof") {
      let i = 1;
      for (const p of projects) {
        const li = document.createElement("li");
        li.textContent = `${i++}. ${p.titulo} ${p.real ? "🟢 Real" : "⚪ Demo"}`;
        ul.appendChild(li);
      }
    } else {
      // while
      let i = 0;
      while (i < projects.length) {
        const p = projects[i];
        const li = document.createElement("li");
        li.textContent = `${i + 1}. ${p.titulo} ${p.real ? "🟢 Real" : "⚪ Demo"}`;
        ul.appendChild(li);
        i++;
      }
    }
  }

  function calcularStats(kind) {
    let total = 0;
    let chars = 0;
    let masLargo = "";

    if (kind === "for") {
      for (let i = 0; i < projects.length; i++) {
        total++;
        chars += projects[i].titulo.length;
        if (projects[i].titulo.length > masLargo.length) masLargo = projects[i].titulo;
      }
    } else if (kind === "forof") {
      for (const p of projects) {
        total++;
        chars += p.titulo.length;
        if (p.titulo.length > masLargo.length) masLargo = p.titulo;
      }
    } else {
      let i = 0;
      while (i < projects.length) {
        const p = projects[i];
        total++;
        chars += p.titulo.length;
        if (p.titulo.length > masLargo.length) masLargo = p.titulo;
        i++;
      }
    }

    statsBox.innerHTML = `
      <p>Total proyectos: <strong>${total}</strong></p>
      <p>Caracteres totales en títulos: <strong>${chars}</strong></p>
      <p>Título más largo: <strong>${masLargo || "—"}</strong></p>
    `;
  }

  btnGen.addEventListener("click", (e) => {
    e.preventDefault();
    const kind = currentKind();
    pintarLista(kind);
    calcularStats(kind);
  });

  btnClean.addEventListener("click", (e) => {
    e.preventDefault();
    ul.innerHTML = "";
    statsBox.innerHTML = `
      <p>Total proyectos: —</p>
      <p>Caracteres totales en títulos: —</p>
      <p>Título más largo: —</p>
    `;
  });
})();
