// Booleanos aplicados al portfolio: disponibilidad + filtro
(function () {
  // --- Panel A: disponibilidad ---
  const btnDisp = document.getElementById('btn-disponible');
  const btnNoDisp = document.getElementById('btn-no-disponible');
  const estado = document.getElementById('estado');
  const cta = document.getElementById('cta');

  // Si este bloque no existe en la página, no hacemos nada
  if (!btnDisp || !btnNoDisp || !estado || !cta) return;

  let disponible = false;

  function pintarDisponibilidad() {
    estado.textContent = `Estado: ${disponible ? 'Disponible ✅' : 'No disponible ❌'}`;
    cta.style.display = disponible ? 'block' : 'none';
  }

  btnDisp.addEventListener('click', (e) => {
    e.preventDefault();
    disponible = true;
    pintarDisponibilidad();
  });

  btnNoDisp.addEventListener('click', (e) => {
    e.preventDefault();
    disponible = false;
    pintarDisponibilidad();
  });

  pintarDisponibilidad();

  // --- Panel B: filtro de proyectos ---
  const chkReales = document.getElementById('chk-reales');
  const listaProyectos = document.getElementById('lista-proyectos');

  if (!chkReales || !listaProyectos) return;

  const proyectos = [
    { titulo: "Landing IFCD0110", real: true },
    { titulo: "SPA Curso HTML/CSS/JS", real: true },
    { titulo: "Portfolio · Animaciones", real: false },
    { titulo: "Prácticas DOM y Eventos", real: false },
  ];

  function pintarProyectos() {
    const soloReales = chkReales.checked; // boolean
    const data = soloReales ? proyectos.filter(p => p.real) : proyectos;

    listaProyectos.innerHTML = '';
    data.forEach(p => {
      const li = document.createElement('li');
      li.textContent = `${p.titulo} ${p.real ? '🟢 Real' : '⚪ Demo'}`;
      listaProyectos.appendChild(li);
    });
  }

  chkReales.addEventListener('change', pintarProyectos);
  pintarProyectos();
})();
