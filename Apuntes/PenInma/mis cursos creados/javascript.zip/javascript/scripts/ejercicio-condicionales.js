// Ejercicio de Condicionales: acceso por rol/login y etiqueta de proyecto
(function () {
  const $ = (id) => document.getElementById(id);

  // ---- Panel A: Acceso ----
  const selRol   = $("sel-rol");
  const chkLogin = $("chk-logueado");
  const btnAcc   = $("btn-eval-acceso");
  const outAcc   = $("out-acceso");

  if (selRol && chkLogin && btnAcc && outAcc) {
    btnAcc.addEventListener("click", (e) => {
      e.preventDefault();

      const rol = selRol.value;          // visitante | editor | admin
      const log = chkLogin.checked;      // true | false
      let permiso;

      if (!log) {
        permiso = "Acceso denegado (necesitas iniciar sesión).";
      } else {
        // switch por rol
        switch (rol) {
          case "admin":
            permiso = "Acceso total al panel.";
            break;
          case "editor":
            permiso = "Acceso parcial (edición de contenido).";
            break;
          default:
            permiso = "Acceso de solo lectura.";
        }
      }
      outAcc.textContent = "Resultado: " + permiso;
    });
  }

  // ---- Panel B: Etiqueta ----
  const inVisitas = $("in-visitas");
  const inRating  = $("in-rating");
  const inReal    = $("in-real");
  const btnTag    = $("btn-eval-etiqueta");
  const outTag    = $("out-etiqueta");

  if (inVisitas && inRating && inReal && btnTag && outTag) {
    btnTag.addEventListener("click", (e) => {
      e.preventDefault();

      const visitas = Number(inVisitas.value) || 0;
      const rating  = Number(inRating.value)  || 0;
      const real    = !!inReal.checked;

      let etiqueta;

      if (real && visitas >= 1000) {
        etiqueta = "Destacado";
      } else if (rating >= 4.7) {
        etiqueta = "Top ⭐";
      } else {
        // Ternario para una etiqueta base con “real” o “demo”
        etiqueta = real ? "Normal (Real)" : "Normal (Demo)";
      }

      outTag.textContent = "Etiqueta: " + etiqueta;
    });
  }
})();
