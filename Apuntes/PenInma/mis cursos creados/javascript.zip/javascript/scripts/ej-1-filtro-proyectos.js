(function () {
  const datos = [
    { titulo: "Landing IFCD0110", real: true },
    { titulo: "SPA HTML/CSS/JS", real: true },
    { titulo: "Portfolio Animaciones", real: false },
    { titulo: "Prácticas DOM y Eventos", real: false },
    { titulo: "Tienda Demo (Carrito)", real: false },
  ];
  const $ = (id) => document.getElementById(id);
  const inpSearch = $("busqueda-proy");
  const chkReal   = $("solo-reales");
  const selOrden  = $("orden-proy");
  const ul        = $("lista-proy");
  const resumen   = $("resumen-proy");
  if (!inpSearch || !ul) return;

  function normalizar(s){ return s.normalize("NFD").replace(/\p{Diacritic}/gu,"").toLowerCase(); }

  function filtrar() {
    const q = normalizar(inpSearch.value || "");
    const soloReales = chkReal && chkReal.checked;
    let lista = datos.filter(p => (!soloReales || p.real) && normalizar(p.titulo).includes(q));

    switch (selOrden && selOrden.value) {
      case "za":      lista.sort((a,b)=>b.titulo.localeCompare(a.titulo)); break;
      case "largos":  lista.sort((a,b)=>b.titulo.length - a.titulo.length); break;
      default:        lista.sort((a,b)=>a.titulo.localeCompare(b.titulo));
    }

    ul.innerHTML = "";
    lista.forEach(p => {
      const li = document.createElement("li");
      li.textContent = `${p.titulo} ${p.real ? "🟢 Real" : "⚪ Demo"}`;
      ul.appendChild(li);
    });
    if (resumen) resumen.textContent = `${lista.length} resultado${lista.length!==1?"s":""}`;
  }

  ["input","change"].forEach(ev=>{
    inpSearch.addEventListener(ev, filtrar);
    if (chkReal)  chkReal.addEventListener(ev, filtrar);
    if (selOrden) selOrden.addEventListener(ev, filtrar);
  });

  filtrar(); // estado inicial
})();
