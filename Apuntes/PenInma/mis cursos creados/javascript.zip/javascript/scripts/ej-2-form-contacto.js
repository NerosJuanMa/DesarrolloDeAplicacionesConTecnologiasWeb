(function () {
  const form   = document.getElementById("form-contacto-ej");
  const estado = document.getElementById("fc-estado");
  const msg    = document.getElementById("fc-mensaje");
  const cnt    = document.getElementById("fc-contador");
  if (!form) return;

  // contador en vivo
  const MAX = 500;
  function pintarContador(){ if(cnt) cnt.textContent = Math.min(msg.value.length, MAX); }
  msg.addEventListener("input", pintarContador); pintarContador();

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!form.checkValidity() || (msg.value.trim().length < 10)) {
      form.reportValidity();
      if (estado) estado.textContent = "Revisa los campos: el mensaje debe tener al menos 10 caracteres.";
      return;
    }
    if (estado) estado.textContent = "Enviando… ⏳";
    // Simulación de envío (sustituye por fetch a tu backend)
    await new Promise(r => setTimeout(r, 900));
    if (estado) estado.textContent = "¡Mensaje enviado! ✅";
    form.reset(); pintarContador();
  });
})();
