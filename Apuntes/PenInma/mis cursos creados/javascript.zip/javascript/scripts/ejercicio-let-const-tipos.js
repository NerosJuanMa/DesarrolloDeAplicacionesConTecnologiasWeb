// ===== Panel A: let vs const =====
(function () {
  const valContador = document.getElementById('val-contador');
  const valPi = document.getElementById('val-pi');
  const btnInc = document.getElementById('btn-inc');
  const btnReset = document.getElementById('btn-reset');
  const btnReasignarPi = document.getElementById('btn-reasignar-pi');
  const log = document.getElementById('log');

  // Si no existe el panel en esta página, salimos
  if (!valContador || !valPi || !btnInc || !btnReset || !btnReasignarPi || !log) return;

  let contador = 0;         // let: permite reasignación
  const PI = 3.1416;        // const: NO permite reasignación

  function pintarLetConst() {
    valContador.textContent = String(contador);
    valPi.textContent = String(PI);
  }

  btnInc.addEventListener('click', (e) => {
    e.preventDefault();
    contador++;
    pintarLetConst();
    log.textContent = 'Has incrementado el contador (let).';
  });

  btnReset.addEventListener('click', (e) => {
    e.preventDefault();
    contador = 0;
    pintarLetConst();
    log.textContent = 'Contador reiniciado (let).';
  });

  btnReasignarPi.addEventListener('click', (e) => {
    e.preventDefault();
    try {
      // Esto debe fallar: no se puede reasignar una constante
      // @ts-ignore
      PI = 100;
    } catch (_) {
      log.textContent = '❌ No puedes reasignar una constante (PI).';
    }
  });

  pintarLetConst();
})();

// ===== Panel B: tipos de variables =====
(function () {
  const panel = document.getElementById('x-panel');
  if (!panel) return;

  const xValor = document.getElementById('x-valor');
  const xType = document.getElementById('x-type');
  const xExtra = document.getElementById('x-extra');

  let x; // probamos distintos tipos con la misma variable

  function asignarX(tipo) {
    switch (tipo) {
      case 'number': x = 42; break;
      case 'string': x = 'Hola'; break;
      case 'true':   x = true; break;
      case 'false':  x = false; break;
      case 'null':   x = null; break;
      case 'undef':  x = undefined; break;
      case 'array':  x = [1, 2, 3]; break;
      case 'object': x = { a: 1 }; break;
    }
    pintarX();
  }

  function pintarX() {
    const tipo = typeof x;
    const esArray = Array.isArray(x);
    const valor = (tipo === 'object') ? JSON.stringify(x) : String(x);

    xValor.textContent = valor;
    xType.textContent = tipo;

    let extra = '';
    if (x === null) {
      extra = 'Ojo: null es un valor especial; typeof null es "object" por una peculiaridad histórica.';
    } else if (esArray) {
      extra = 'Un array es un objeto: typeof x es "object", pero Array.isArray(x) es true.';
    }
    xExtra.textContent = extra;
  }

  document.querySelectorAll('[data-kind]').forEach(b => {
    b.addEventListener('click', (e) => {
      e.preventDefault();
      asignarX(b.dataset.kind);
    });
  });

  // Estado inicial
  asignarX('number');
})();
