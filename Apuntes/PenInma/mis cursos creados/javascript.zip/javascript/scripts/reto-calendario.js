(function () {
  const grid  = document.getElementById('cal-grid');
  const title = document.getElementById('cal-title');
  const prev  = document.getElementById('cal-prev');
  const next  = document.getElementById('cal-next');
  const today = document.getElementById('cal-today');

  const selLbl = document.getElementById('cal-selected');
  const area   = document.getElementById('cal-text');
  const save   = document.getElementById('cal-save');
  const msg    = document.getElementById('cal-msg');

  const KEY = 'cal-notas'; // { 'YYYY-MM-DD': 'texto' }
  let notas = JSON.parse(localStorage.getItem(KEY) || '{}');

  let current = new Date(); current.setDate(1); // primer día del mes
  let selected = null; // 'YYYY-MM-DD'

  const ymd = (d) => d.toISOString().slice(0,10);

  function pintar() {
    grid.innerHTML = '';

    const y = current.getFullYear();
    const m = current.getMonth();
    title.textContent = current.toLocaleDateString('es-ES', { month:'long', year:'numeric' });

    // Encabezados
    const dias = ['L','M','X','J','V','S','D'];
    dias.forEach(d => {
      const h = document.createElement('div');
      h.textContent = d;
      h.style.textAlign = 'center';
      h.style.fontWeight = '700';
      grid.appendChild(h);
    });

    // Calcula huecos del primer día (lunes como 0)
    const first = new Date(y, m, 1);
    const start = (first.getDay() + 6) % 7; // 0..6 (lunes=0)
    const daysInMonth = new Date(y, m+1, 0).getDate();

    // Días del mes anterior visibles
    const prevDays = new Date(y, m, 0).getDate();
    for (let i = 0; i < start; i++) {
      const n = prevDays - start + 1 + i;
      grid.appendChild(celda(n, y, m-1, true));
    }

    // Días del mes actual
    for (let d = 1; d <= daysInMonth; d++) {
      grid.appendChild(celda(d, y, m, false));
    }

    // Completar filas con primeros del siguiente mes
    const total = 7 + start + daysInMonth; // 7 encabezados + celdas
    const resto = total % 7 ? 7 - (total % 7) : 0;
    for (let i = 1; i <= resto; i++) {
      grid.appendChild(celda(i, y, m+1, true));
    }
  }

  function celda(d, y, m, out) {
    const cell = document.createElement('button');
    cell.type = 'button';
    cell.className = 'cal-cell';
    if (out) cell.dataset.out = '1';

    const fecha = new Date(y, m, d);
    const id = ymd(fecha);
    const div = document.createElement('div');
    div.className = 'd';
    div.textContent = String(d);
    cell.appendChild(div);

    // Hoy
    const hoy = ymd(new Date());
    if (id === hoy && !out) cell.classList.add('today');
    // Nota
    if (notas[id]) cell.classList.add('has-note');

    cell.addEventListener('click', () => seleccionarDia(id));
    return cell;
  }

  function seleccionarDia(id) {
    selected = id;
    selLbl.textContent = `Nota para ${id}`;
    area.value = notas[id] || '';
    msg.textContent = '';
  }

  prev.addEventListener('click', (e) => {
    e.preventDefault();
    current.setMonth(current.getMonth() - 1);
    pintar();
  });

  next.addEventListener('click', (e) => {
    e.preventDefault();
    current.setMonth(current.getMonth() + 1);
    pintar();
  });

  today.addEventListener('click', (e) => {
    e.preventDefault();
    current = new Date(); current.setDate(1);
    pintar();
  });

  save.addEventListener('click', (e) => {
    e.preventDefault();
    if (!selected) { msg.textContent = 'Selecciona un día primero.'; return; }
    const v = area.value.trim();
    if (v) notas[selected] = v; else delete notas[selected];
    localStorage.setItem(KEY, JSON.stringify(notas));
    msg.textContent = '✅ Nota guardada';
    pintar(); // refresca iconos ✎
  });

  pintar();
})();
