// Script básico: saludo según la hora
let saludo;
let hora = new Date().getHours();

if (hora < 13) {
  saludo = "¡Buenos días! ☀️ Bienvenido a mi portfolio.";
} else if (hora < 20) {
  saludo = "¡Buenas tardes! 🌞 Gracias por  conocerme. ¡Espero que disfrutes de mi trabajo.";
} else {
  saludo = "¡Buenas noches! 🌙 Gracias por visitar mi portfolio.";
}

document.getElementById("saludo").textContent = saludo + " 🦉"; // <- pinta el saludo
