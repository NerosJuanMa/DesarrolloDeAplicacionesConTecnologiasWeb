(function () {
  const productos = [
    { id:1, titulo:"Plantilla Landing", cat:"web",  precio: 19.99 },
    { id:2, titulo:"Kit UI Iconos",   cat:"ui",   precio: 9.50  },
    { id:3, titulo:"Curso JS Esencial",cat:"curso",precio: 49.00 },
    { id:4, titulo:"Portfolio Pro",   cat:"web",  precio: 29.00 },
  ];

  const grid   = document.getElementById('grid-prod');
  const filtro = document.getElementById('filtro-cat');
  const buscar = document.getElementById('buscar-prod');

  const cartList = document.getElementById('cart-list');
  const totalBox = document.getElementById('cart-total');
  const cuponInp = document.getElementById('cupon');
  const cupBtn   = document.getElementById('aplicar-cupon');

  const CART_KEY = 'mini-cart';
  const CUPON_KEY = 'mini-cupon';
  let cart = JSON.parse(localStorage.getItem(CART_KEY) || '[]'); // [{id,cantidad}]
  let cupon = localStorage.getItem(CUPON_KEY) || ''; // 'JS10' = 10%

  function renderProductos(data) {
    grid.innerHTML = '';
    data.forEach(p => {
      const card = document.createElement('div');
      card.className = 'feature-item';
      card.innerHTML = `
        <h3>${p.titulo}</h3>
        <p>Categoría: <strong>${p.cat}</strong></p>
        <p>Precio: <strong>${p.precio.toFixed(2)} €</strong></p>
        <p><a href="#" data-add="${p.id}" class="btn">Añadir al carrito</a></p>
      `;
      grid.appendChild(card);
    });
  }

  function filtra() {
    const cat = filtro.value;
    const q   = buscar.value.trim().toLowerCase();
    let data = productos;
    if (cat) data = data.filter(p => p.cat === cat);
    if (q)   data = data.filter(p => p.titulo.toLowerCase().includes(q));
    renderProductos(data);
  }

  function addToCart(id) {
    const item = cart.find(x => x.id === id);
    if (item) item.cantidad += 1;
    else cart.push({ id, cantidad: 1 });
    persist();
    renderCart();
  }

  function removeFromCart(id) {
    cart = cart.filter(x => x.id !== id);
    persist();
    renderCart();
  }

  function setQty(id, qty) {
    const it = cart.find(x => x.id === id);
    if (!it) return;
    it.cantidad = Math.max(1, qty);
    persist();
    renderCart();
  }

  function getProducto(id) { return productos.find(p => p.id === id); }

  function calcTotal() {
    let sum = 0;
    for (const it of cart) {
      const p = getProducto(it.id);
      sum += p.precio * it.cantidad;
    }
    if (cupon === 'JS10') sum *= 0.9;
    return sum;
  }

  function renderCart() {
    cartList.innerHTML = '';
    if (!cart.length) {
      cartList.innerHTML = '<li>(Carrito vacío)</li>';
      totalBox.innerHTML = '<strong>Total:</strong> 0 €';
      return;
    }
    for (const it of cart) {
      const p = getProducto(it.id);
      const li = document.createElement('li');
      li.innerHTML = `
        ${p.titulo} — ${p.precio.toFixed(2)} € ×
        <input type="number" min="1" value="${it.cantidad}" style="width:4rem" data-qty="${it.id}">
        = <strong>${(p.precio * it.cantidad).toFixed(2)} €</strong>
        <a href="#" data-del="${it.id}" class="btn btn-secondary" style="margin-left:.5rem">Quitar</a>
      `;
      cartList.appendChild(li);
    }
    totalBox.innerHTML = `<strong>Total:</strong> ${calcTotal().toFixed(2)} € ${cupon==='JS10' ? '(cupón -10%)' : ''}`;
  }

  function persist() {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
    if (cupon) localStorage.setItem(CUPON_KEY, cupon); else localStorage.removeItem(CUPON_KEY);
  }

  // Delegación en grid para “Añadir”
  grid.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-add]');
    if (!btn) return;
    e.preventDefault();
    addToCart(Number(btn.dataset.add));
  });

  // Delegación en carrito
  cartList.addEventListener('click', (e) => {
    const del = e.target.closest('[data-del]');
    if (!del) return;
    e.preventDefault();
    removeFromCart(Number(del.dataset.del));
  });
  cartList.addEventListener('input', (e) => {
    const qty = e.target.closest('[data-qty]');
    if (!qty) return;
    setQty(Number(qty.dataset.qty), Number(qty.value || 1));
  });

  // Filtros
  filtro.addEventListener('change', filtra);
  buscar.addEventListener('input', () => filtra());

  // Cupón
  cupBtn.addEventListener('click', (e) => {
    e.preventDefault();
    const v = cuponInp.value.trim().toUpperCase();
    cupon = (v === 'JS10') ? 'JS10' : '';
    persist(); renderCart();
  });

  // Inicial
  filtra();
  renderCart();
})();
