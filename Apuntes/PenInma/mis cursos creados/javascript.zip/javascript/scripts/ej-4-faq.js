(function () {
  const list = document.getElementById('faq');

  list.addEventListener('click', (e) => {
    const btn = e.target.closest('.faq-q');
    if (!btn) return;
    const panel = btn.nextElementSibling;
    const abierto = !panel.hasAttribute('hidden');
    // Cerrar todos
    list.querySelectorAll('.faq-a').forEach(a => a.hidden = true);
    // Abrir actual si estaba cerrado
    if (!abierto) panel.hidden = false;
  });
})();
