(function () {
  const btn   = document.getElementById('dd-btn');
  const menu  = document.getElementById('dd-menu');
  const msg   = document.getElementById('dd-msg');

  if (!btn || !menu) return;

  const items = () => [...menu.querySelectorAll('[role="menuitem"]')];

  function abrir() {
    menu.hidden = false;
    btn.setAttribute('aria-expanded', 'true');
    // foco en el primer item
    const first = items()[0];
    if (first) first.focus();
    // escuchar fuera y teclado
    document.addEventListener('click', onClickFuera);
    document.addEventListener('keydown', onKeyClose);
    menu.addEventListener('keydown', onKeyNav);
  }

  function cerrar(focusBtn = true) {
    menu.hidden = true;
    btn.setAttribute('aria-expanded', 'false');
    document.removeEventListener('click', onClickFuera);
    document.removeEventListener('keydown', onKeyClose);
    menu.removeEventListener('keydown', onKeyNav);
    if (focusBtn) btn.focus();
  }

  function toggle(e) {
    e.preventDefault();
    menu.hidden ? abrir() : cerrar();
  }

  function onClickFuera(e) {
    if (!menu.contains(e.target) && e.target !== btn) cerrar(false);
  }

  function onKeyClose(e) {
    if (e.key === 'Escape' && !menu.hidden) {
      e.preventDefault();
      cerrar();
    }
  }

  function onKeyNav(e) {
    const arr = items();
    const i = arr.indexOf(document.activeElement);
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      (arr[i + 1] || arr[0])?.focus();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      (arr[i - 1] || arr[arr.length - 1])?.focus();
    } else if (e.key === 'Home') {
      e.preventDefault();
      arr[0]?.focus();
    } else if (e.key === 'End') {
      e.preventDefault();
      arr[arr.length - 1]?.focus();
    }
  }

  // Abrir/cerrar con botón
  btn.addEventListener('click', toggle);
  btn.addEventListener('keydown', (e) => {
    if ((e.key === 'ArrowDown' || e.key === ' ') && menu.hidden) {
      e.preventDefault(); abrir();
    }
  });

  // Acción de ejemplo: logout
  menu.addEventListener('click', (e) => {
    const act = e.target.closest('[data-action="logout"]');
    if (act) {
      e.preventDefault();
      msg.textContent = 'Has cerrado sesión (simulado).';
      cerrar();
    } else if (e.target.matches('a[role="menuitem"]')) {
      // para enlaces reales, deja navegar; opcional: cerrar antes
      cerrar(false);
    }
  });
})();
