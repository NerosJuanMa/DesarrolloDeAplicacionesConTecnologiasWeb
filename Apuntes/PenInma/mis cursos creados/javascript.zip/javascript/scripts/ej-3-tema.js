(function () {
  const btn = document.getElementById("btn-tema");
  if (!btn) return;

  const KEY = "preferencia-tema"; // "light" | "dark" | null
  function aplicarTema(valor){
    document.body.dataset.theme = valor || "";
    try { localStorage.setItem(KEY, valor || ""); } catch {}
    btn.textContent = (valor === "light") ? "Cambiar a tema oscuro" : "Cambiar a tema claro";
  }

  // estado inicial: localStorage o preferencia del SO
  const guardado = (()=>{ try { return localStorage.getItem(KEY); } catch { return null; } })();
  const preferSO = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  aplicarTema(guardado || preferSO);

  btn.addEventListener("click", (e) => {
    e.preventDefault();
    const actual = document.body.dataset.theme || preferSO;
    aplicarTema(actual === "light" ? "dark" : "light");
  });
})();
